cd ~/jarlib/thirdparty-jar
java -classpath ./slf4j-api-1.6.1.jar:./guava-18.0.jar:./comms-math3-3.2.jar:./jbox2d-library-2.3.1-SNAPSHOT.jar:./jbox2d-testbed-jogl-2.3.1-SNAPSHOT.jar:./jbox2d-testbed-2.3.1-SNAPSHOT.jar:./jbox2d-serialization-2.3.1-SNAPSHOT.jar org.jbox2d.testbed.framework.j2d.TestbedMain
